-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2016 at 06:57 PM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zhdanov2ru_v1`
--

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE IF NOT EXISTS `lessons` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `teaser` text,
  `text` text,
  `price` smallint(5) unsigned DEFAULT NULL,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `name`, `teaser`, `text`, `price`, `gallery`, `created_at`, `updated_at`) VALUES
(2, 'Создание индивидуального образа', 'В видеоруке мастер поделится с вами своими знаниями и опытом. После оплаты полной версии количество просмотров не ограничено. ', '<p>Текст-описание урока. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web.</p>\n', 1500, NULL, 1463752548, 1463759318);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `panel_models`
--

DROP TABLE IF EXISTS `panel_models`;
CREATE TABLE IF NOT EXISTS `panel_models` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `public_model_name` varchar(64) NOT NULL,
  `sortable` tinyint(1) unsigned DEFAULT NULL,
  `created_at` int(8) unsigned NOT NULL DEFAULT '0',
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `panel_models`
--

INSERT INTO `panel_models` (`id`, `name`, `public_model_name`, `sortable`, `created_at`, `updated_at`) VALUES
(1, 'Test', 'test', NULL, 1450610882, 2016),
(2, 'Panel Models', 'panel_model', 1, 1450611656, 1462226689),
(3, 'Пользователи', 'user', NULL, 1450611739, 1462226475),
(4, 'Видеоуроки', 'lesson', 0, 1463750615, 1463755575);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `text` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL,
  `test` tinyint(1) unsigned DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `name`, `text`, `gallery`, `created_at`, `updated_at`, `test`) VALUES
(8, '', '', '', 1462224925, 1462542127, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `panel_model_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `panel_model_ids`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '220619@gmail.com', '$2y$10$rdpRDppdACBZGc/VVdMjpulXMgha9t1V55Uvd9bN.zVjhIVKxmFkW', 'getcoFGzKstoQr0I2AE0dFAKDnWNJNkWnpwOoeW7FaSMJ1anyiS39TBEaA93', '1', 0, 1463750641);

-- --------------------------------------------------------

--
-- Table structure for table `user_panel_models`
--

DROP TABLE IF EXISTS `user_panel_models`;
CREATE TABLE IF NOT EXISTS `user_panel_models` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `panel_model_id` int(10) unsigned NOT NULL DEFAULT '0',
  `c` tinyint(1) unsigned DEFAULT NULL,
  `r` tinyint(1) unsigned DEFAULT NULL,
  `u` tinyint(1) unsigned DEFAULT NULL,
  `d` tinyint(1) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_panel_models`
--

INSERT INTO `user_panel_models` (`user_id`, `panel_model_id`, `c`, `r`, `u`, `d`) VALUES
(1, 1, 1, 1, 1, 1),
(1, 2, 1, 1, 1, 1),
(1, 3, 1, 1, 1, 1),
(1, 4, 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `panel_models`
--
ALTER TABLE `panel_models`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_panel_models`
--
ALTER TABLE `user_panel_models`
 ADD UNIQUE KEY `index4` (`user_id`,`panel_model_id`), ADD KEY `fk_user_panel_models_1_idx` (`user_id`), ADD KEY `fk_user_panel_models_2_idx` (`panel_model_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `panel_models`
--
ALTER TABLE `panel_models`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_panel_models`
--
ALTER TABLE `user_panel_models`
ADD CONSTRAINT `fk_user_panel_models_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_user_panel_models_2` FOREIGN KEY (`panel_model_id`) REFERENCES `panel_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
