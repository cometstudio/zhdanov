-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 22, 2016 at 06:51 PM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zhdanov2ru_v1`
--

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE IF NOT EXISTS `lessons` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `theme_id` int(10) unsigned DEFAULT NULL,
  `length_hr` smallint(5) unsigned DEFAULT NULL,
  `length_min` smallint(5) unsigned DEFAULT NULL,
  `price` smallint(5) unsigned DEFAULT NULL,
  `teaser` text,
  `text` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `name`, `author_id`, `theme_id`, `length_hr`, `length_min`, `price`, `teaser`, `text`, `gallery`, `created_at`, `updated_at`) VALUES
(2, 'Создание индивидуального образа', 2, 2, 2, 31, 1500, 'В видеоруке мастер поделится с вами своими знаниями и опытом. После оплаты полной версии количество просмотров не ограничено. ', '<p>Текст-описание урока. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web.</p>\n', 'jmrvDAP635HdXRhIJrIj62Gp', 1463752548, 1466448433),
(3, 'A lesson by Irina', 3, 2, 1, 0, 0, 'Description', '<p>Text</p>\n', 'o9t9meMiGXdXj5IuMSWygrJg', 1466514632, 1466515546);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `panel_models`
--

DROP TABLE IF EXISTS `panel_models`;
CREATE TABLE IF NOT EXISTS `panel_models` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `public_model_name` varchar(64) NOT NULL,
  `sortable` tinyint(1) unsigned DEFAULT NULL,
  `created_at` int(8) unsigned NOT NULL DEFAULT '0',
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `panel_models`
--

INSERT INTO `panel_models` (`id`, `name`, `public_model_name`, `sortable`, `created_at`, `updated_at`) VALUES
(1, 'Test', 'test', NULL, 1450610882, 2016),
(2, 'Panel Models', 'panel_model', 0, 1450611656, 1464636679),
(3, 'Пользователи', 'user', NULL, 1450611739, 1462226475),
(4, 'Видеоуроки', 'lesson', 0, 1463750615, 1463755575),
(5, 'Вебинары', 'webinar', 0, 1464124279, 1464124279),
(6, 'Товары', 'product', 0, 1464636725, 1464636775),
(7, 'Видеоканал', 'videochannel', 0, 1466592806, 1466592806);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) unsigned NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `vendor_code` varchar(32) DEFAULT NULL,
  `price` smallint(5) unsigned DEFAULT NULL,
  `audience_id` int(10) unsigned DEFAULT NULL,
  `teaser` text,
  `text` text,
  `recommendations` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `active`, `name`, `vendor_code`, `price`, `audience_id`, `teaser`, `text`, `recommendations`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 1, 'Фен PARLUX 385', '564576', 1290, 1, 'Набор препаратов для защиты, восстановления, укрепления волос и придания им восхитительного здорового блеска. Шампунь, маска и эликсир на основе кератина и масла арганы обеспечивают великолепное увлажнение, питание и непревзойденную защиту волос от повреждения.', '<p>Препараты набора, усиливая и дополняя действие друг друга, восстанавливают внешнюю и внутреннюю структуру волоса, обеспечивая защиту от повреждения. Сочетание активных компонентов арганового масла и кератина: витаминов, жирных кислот, микроэлементов, аминокислот великолепно восстанавливает поврежденную структуру волос до самых кончиков. Набор обеспечивает великолепное увлажнение и питание, волосы становятся блестящими, гладкими и шелковистыми.</p>\n\n<p> </p>\n\n<p><strong>Состав набора:</strong></p>\n\n<p> </p>\n\n<p>Увлажняющий кератиновый шампунь с маслом арганы, 250 мл Восстанавливающая кератиновая маска с маслом арганы, 250 мл Укрепляющий кератиновый эликсир с маслом арганы, 250 мл.</p>\n\n<p> </p>\n\n<p><strong>Действие активных компонентов:</strong></p>\n\n<p> </p>\n\n<p>Масло арганового дерева признано одним из эффективных средств для восстановления и защиты волос, поддержания их здоровья. Масло арганы превосходно защищает волосы от внешних воздействий, великолепно увлажняет и оказывает питательное действие на волосы и кожу головы, укрепляет и восстанавливает структуру волос.</p>\n\n<p> </p>\n\n<p>Кератин полностью восстанавливает как внешнюю, так и внутреннюю структуру волос, укрепляет сцепление между чешуйками кутикулы, устраняет отслаивание клеток на волосяном стержне. Защищают волосы по всей длине от корней до кончиков.</p>\n\n<p> </p>\n\n<p>Масло макадамии оказывает восстанавливающее и увлажняющее действие на волосы, устраняет сухость и ломкость волос, разглаживает секущиеся кончики, насыщает необходимыми веществами по всей длине, возвращает гладкость и блеск.</p>\n\n<p> </p>\n\n<p>Пантенол (провитамин В5). Восстанавливает структуру волоса, стимулирует синтез кератина, обладает смягчающими и себорегулирующими свойствами.</p>\n\n<p> </p>\n\n<p>Витамин Е оказывает антиоксидантное действие, укрепляет здоровье волос, стимулирует их защитные природные свойства.</p>\n', '<p>Рекомендации</p>\n', 'EwzswqZrHtMZE2kVMYcMDd9y', 1464637346, 1466334011),
(2, 1, 'Фен PARLUX 386', '544', 1000, 2, 'Набор препаратов для защиты, восстановления, укрепления волос и придания им восхитительного здорового блеска. Шампунь, маска и эликсир на основе кератина и масла арганы обеспечивают великолепное увлажнение, питание и непревзойденную защиту волос от повреждения. ', '<p>Препараты набора, усиливая и дополняя действие друг друга, восстанавливают внешнюю и внутреннюю структуру волоса, обеспечивая защиту от повреждения. Сочетание активных компонентов арганового масла и кератина: витаминов, жирных кислот, микроэлементов, аминокислот великолепно восстанавливает поврежденную структуру волос до самых кончиков. Набор обеспечивает великолепное увлажнение и питание, волосы становятся блестящими, гладкими и шелковистыми.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Состав набора:</strong></p>\n\n<p>&nbsp;</p>\n\n<p>Увлажняющий кератиновый шампунь с маслом арганы, 250 мл Восстанавливающая кератиновая маска с маслом арганы, 250 мл Укрепляющий кератиновый эликсир с маслом арганы, 250 мл.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Действие активных компонентов:</strong></p>\n\n<p>&nbsp;</p>\n\n<p>Масло арганового дерева признано одним из эффективных средств для восстановления и защиты волос, поддержания их здоровья. Масло арганы превосходно защищает волосы от внешних воздействий, великолепно увлажняет и оказывает питательное действие на волосы и кожу головы, укрепляет и восстанавливает структуру волос.</p>\n\n<p>&nbsp;</p>\n\n<p>Кератин полностью восстанавливает как внешнюю, так и внутреннюю структуру волос, укрепляет сцепление между чешуйками кутикулы, устраняет отслаивание клеток на волосяном стержне. Защищают волосы по всей длине от корней до кончиков.</p>\n\n<p>&nbsp;</p>\n\n<p>Масло макадамии оказывает восстанавливающее и увлажняющее действие на волосы, устраняет сухость и ломкость волос, разглаживает секущиеся кончики, насыщает необходимыми веществами по всей длине, возвращает гладкость и блеск.</p>\n\n<p>&nbsp;</p>\n\n<p>Пантенол (провитамин В5). Восстанавливает структуру волоса, стимулирует синтез кератина, обладает смягчающими и себорегулирующими свойствами.</p>\n\n<p>&nbsp;</p>\n\n<p>Витамин Е оказывает антиоксидантное действие, укрепляет здоровье волос, стимулирует их защитные природные свойства.</p>\n', '<p>Рекомендации</p>\n', '8XKpU2jnzI3Dwr2IPaErvLHt', 1466354407, 1466354684);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `text` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL,
  `test` tinyint(1) unsigned DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `name`, `text`, `gallery`, `created_at`, `updated_at`, `test`) VALUES
(8, '', '', '', 1462224925, 1462542127, 0);

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'hair-tatoo', 0, NULL),
(2, 'вечерняя причёска', 0, NULL),
(3, 'мода', 0, NULL),
(4, 'свадебная причёска', 0, NULL),
(5, 'техника', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
CREATE TABLE IF NOT EXISTS `timetable` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `theme_id` int(10) unsigned DEFAULT NULL,
  `teaser` text,
  `text` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_author` tinyint(1) unsigned DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `panel_model_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `is_author`, `email`, `password`, `remember_token`, `panel_model_ids`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 0, '220619@gmail.com', '$2y$10$rdpRDppdACBZGc/VVdMjpulXMgha9t1V55Uvd9bN.zVjhIVKxmFkW', 'Q7X9MTgmMXKxm6Rh9QZiEgFxmRuDZfdvzHs2AWQHwk4EhR9mBpjAMlMpjOJq', '1', 0, 1466592821),
(2, 'Юрий Жданов', 1, 'ZhdanovYL@yandex.ru', '$2y$10$rdpRDppdACBZGc/VVdMjpulXMgha9t1V55Uvd9bN.zVjhIVKxmFkW', 'YEkUk3Y4BJTcSX9puV1w3iPlyV6vBpHxEKvOaUFbUdT2tc74e7IaWhilTNq5', NULL, 1464036159, 1466354806),
(3, 'Ирина Агрба', 1, '220ывава619@gmail.com', '$2y$10$Amy4t.6ifq./01DAb1/4kes5Jjcgtoy0oMqdx5c30L5eFStmQCHMa', NULL, NULL, 1464037116, 1464124298);

-- --------------------------------------------------------

--
-- Table structure for table `user_panel_models`
--

DROP TABLE IF EXISTS `user_panel_models`;
CREATE TABLE IF NOT EXISTS `user_panel_models` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `panel_model_id` int(10) unsigned NOT NULL DEFAULT '0',
  `c` tinyint(1) unsigned DEFAULT NULL,
  `r` tinyint(1) unsigned DEFAULT NULL,
  `u` tinyint(1) unsigned DEFAULT NULL,
  `d` tinyint(1) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_panel_models`
--

INSERT INTO `user_panel_models` (`user_id`, `panel_model_id`, `c`, `r`, `u`, `d`) VALUES
(1, 1, 1, 1, 1, 1),
(1, 2, 1, 1, 1, 1),
(1, 3, 1, 1, 1, 1),
(1, 4, 1, 1, 1, 1),
(1, 5, 1, 1, 1, 1),
(1, 6, 1, 1, 1, 1),
(1, 7, 1, 1, 1, 1),
(2, 6, 1, 1, 1, 1),
(3, 4, 1, 1, 1, 1),
(3, 5, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `videochannel`
--

DROP TABLE IF EXISTS `videochannel`;
CREATE TABLE IF NOT EXISTS `videochannel` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `teaser` text,
  `text` text,
  `gallery` text,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videochannel`
--

INSERT INTO `videochannel` (`id`, `name`, `url`, `teaser`, `text`, `gallery`, `created_at`, `updated_at`) VALUES
(2, '#tag', 'http://youtube.com', 'Краткое описание', NULL, 'di3qYPqjAnGvxgWZI1kjjzNh', 1466599644, 1466601711);

-- --------------------------------------------------------

--
-- Table structure for table `webinars`
--

DROP TABLE IF EXISTS `webinars`;
CREATE TABLE IF NOT EXISTS `webinars` (
`id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `theme_id` int(10) unsigned DEFAULT NULL,
  `length_hr` smallint(5) unsigned DEFAULT NULL,
  `length_min` smallint(5) unsigned DEFAULT NULL,
  `price` smallint(5) unsigned DEFAULT NULL,
  `teaser` text,
  `text` text,
  `gallery` text,
  `vacancies` smallint(5) unsigned DEFAULT NULL,
  `participants` smallint(5) unsigned DEFAULT NULL,
  `start_date` varchar(32) DEFAULT NULL,
  `created_at` int(8) unsigned NOT NULL,
  `updated_at` int(8) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `webinars`
--

INSERT INTO `webinars` (`id`, `name`, `author_id`, `theme_id`, `length_hr`, `length_min`, `price`, `teaser`, `text`, `gallery`, `vacancies`, `participants`, `start_date`, `created_at`, `updated_at`) VALUES
(1, 'Двухчасовой вебинар "Основы химической завивки"', 2, 1, 2, 15, 1500, 'Вебинар — мастер-класс в прямом эфире с возможностью получить ответ на интересующие вас вопросы. Во время трансляции будет открыт чат', '<p>Текст-описание вебинара. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web. If your computer or network is protected by a firewall or proxy, make sure that Firefox is permitted to access the Web.</p>\n', 'a8uXIHAw3BbkZKxnsCGZxm5Y', 15, 8, '23.06.2016', 1464125378, 1466610389),
(2, 'Rock it!', 3, 1, 1, 0, 1000, 'Description', '<p>Text</p>\n', 'HNThlhCyXdaGR9zyFaQt6ANj', 10, 2, '24.06.2016', 1466516915, 1466610327);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_lessons_11_idx` (`theme_id`), ADD KEY `fk_lessons_2_idx` (`author_id`);

--
-- Indexes for table `panel_models`
--
ALTER TABLE `panel_models`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_timetable_1_idx` (`author_id`), ADD KEY `fk_timetable_2_idx` (`theme_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_panel_models`
--
ALTER TABLE `user_panel_models`
 ADD UNIQUE KEY `index4` (`user_id`,`panel_model_id`), ADD KEY `fk_user_panel_models_1_idx` (`user_id`), ADD KEY `fk_user_panel_models_2_idx` (`panel_model_id`);

--
-- Indexes for table `videochannel`
--
ALTER TABLE `videochannel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webinars`
--
ALTER TABLE `webinars`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_webinars_1_idx` (`theme_id`), ADD KEY `fk_webinars_2_idx` (`author_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `panel_models`
--
ALTER TABLE `panel_models`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `videochannel`
--
ALTER TABLE `videochannel`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `webinars`
--
ALTER TABLE `webinars`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `lessons`
--
ALTER TABLE `lessons`
ADD CONSTRAINT `fk_lessons_1` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `fk_lessons_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
ADD CONSTRAINT `fk_timetable_2` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `fk_timetable_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user_panel_models`
--
ALTER TABLE `user_panel_models`
ADD CONSTRAINT `fk_user_panel_models_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_user_panel_models_2` FOREIGN KEY (`panel_model_id`) REFERENCES `panel_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `webinars`
--
ALTER TABLE `webinars`
ADD CONSTRAINT `fk_webinars_1` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `fk_webinars_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
